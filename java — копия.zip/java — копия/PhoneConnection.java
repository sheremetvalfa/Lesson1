public interface PhoneConnection {
    public void call();
    public void sendSMS();

}
