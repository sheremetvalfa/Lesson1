public interface PhoneMedia {
    public void makePhoto();
    public void recordVideo();

}
