public abstract class Phone  {
    String name;
    String model;



}
